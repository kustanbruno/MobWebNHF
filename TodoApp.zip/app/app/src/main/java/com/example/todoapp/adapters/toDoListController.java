package com.example.todoapp.adapters;

public interface toDoListController {
    public void deleteTodo(int position);
    public void markTodoAsDone(int position);
    public void editTodo(int position);
}
